
export type ServiceType = 'WEB_DEV' | 'EBOOK_WRITING' | 'ECOMMERCE';

export interface ServicePackage {
  id: string;
  type: ServiceType;
  title: string;
  description: string;
  priceRange: string;
  features: string[];
  iconName: string;
  imageUrl: string; // Added image URL
  faqs?: { question: string; answer: string }[];
}

export interface BookingSlot {
  date: Date;
  time: string;
  available: boolean;
}

export interface UserBookingDetails {
  name: string;
  email: string;
  projectDescription: string;
  serviceId: string;
  slot?: BookingSlot;
}

export interface AiAnalysisResult {
  recommendedServiceId: string;
  analysis: string;
  estimatedTimeline: string;
  suggestedNextSteps: string[];
}

export interface Client {
  id: string;
  name: string;
  email: string;
  phone: string;
  projectHistory: string[];
  notes: string;
  createdAt: Date;
}

export interface PortfolioItem {
  id: string;
  title: string;
  category: string;
  imageUrl: string;
  websiteUrl: string;
}

export interface Testimonial {
  id: string;
  clientName: string;
  company: string;
  content: string;
  rating: number; // 1-5
  avatarUrl: string;
}
