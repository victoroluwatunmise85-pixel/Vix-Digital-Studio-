import React from 'react';
import { UserBookingDetails } from '../types';

interface BookingFormProps {
  details: Partial<UserBookingDetails>;
  onChange: (field: keyof UserBookingDetails, value: string) => void;
}

export const BookingForm: React.FC<BookingFormProps> = ({ details, onChange }) => {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Full Name</label>
          <input
            type="text"
            value={details.name || ''}
            onChange={(e) => onChange('name', e.target.value)}
            className="w-full rounded-lg border-slate-200 focus:ring-brand-500 focus:border-brand-500 px-4 py-2.5 bg-white border"
            placeholder="John Doe"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Email Address</label>
          <input
            type="email"
            value={details.email || ''}
            onChange={(e) => onChange('email', e.target.value)}
            className="w-full rounded-lg border-slate-200 focus:ring-brand-500 focus:border-brand-500 px-4 py-2.5 bg-white border"
            placeholder="john@example.com"
          />
        </div>
      </div>
      <div>
        <label className="block text-sm font-medium text-slate-700 mb-1">Project Details</label>
        <textarea
          value={details.projectDescription || ''}
          onChange={(e) => onChange('projectDescription', e.target.value)}
          rows={4}
          className="w-full rounded-lg border-slate-200 focus:ring-brand-500 focus:border-brand-500 px-4 py-2.5 bg-white border"
          placeholder="Tell us more about what you need..."
        />
        <p className="text-xs text-slate-500 mt-1">
          Please include any specific deadlines or constraints.
        </p>
      </div>
    </div>
  );
};
