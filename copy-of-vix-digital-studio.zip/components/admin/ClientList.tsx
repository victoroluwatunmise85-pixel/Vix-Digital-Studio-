import React, { useState } from 'react';
import { Client } from '../../types';
import { Button } from '../ui/Button';
import { Search, Mail, Phone, Edit, FileText, ArrowUpDown } from 'lucide-react';

interface ClientListProps {
  clients: Client[];
  onEdit: (client: Client) => void;
  onDelete: (id: string) => void;
}

type SortOption = 'name-asc' | 'name-desc' | 'date-newest' | 'date-oldest';

export const ClientList: React.FC<ClientListProps> = ({ clients, onEdit, onDelete }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [sortOption, setSortOption] = useState<SortOption>('date-newest');

  // Filter first
  const filteredClients = clients.filter(c => 
    c.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    c.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Then sort
  const sortedClients = [...filteredClients].sort((a, b) => {
    switch (sortOption) {
      case 'name-asc':
        return a.name.localeCompare(b.name);
      case 'name-desc':
        return b.name.localeCompare(a.name);
      case 'date-newest':
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      case 'date-oldest':
        return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
      default:
        return 0;
    }
  });

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
          <input
            type="text"
            placeholder="Search clients..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-brand-500 focus:outline-none"
          />
        </div>
        
        <div className="relative min-w-[180px]">
          <ArrowUpDown className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
          <select
            value={sortOption}
            onChange={(e) => setSortOption(e.target.value as SortOption)}
            className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-brand-500 focus:outline-none appearance-none bg-white cursor-pointer"
          >
            <option value="date-newest">Newest First</option>
            <option value="date-oldest">Oldest First</option>
            <option value="name-asc">Name (A-Z)</option>
            <option value="name-desc">Name (Z-A)</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {sortedClients.length > 0 ? (
          sortedClients.map((client) => (
            <div key={client.id} className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-4">
                <div>
                  <h3 className="text-lg font-bold text-slate-900">{client.name}</h3>
                  <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4 mt-1">
                    <a href={`mailto:${client.email}`} className="text-sm text-slate-500 hover:text-brand-600 flex items-center gap-1">
                      <Mail className="w-3 h-3" /> {client.email}
                    </a>
                    {client.phone && (
                       <a href={`tel:${client.phone}`} className="text-sm text-slate-500 hover:text-brand-600 flex items-center gap-1">
                        <Phone className="w-3 h-3" /> {client.phone}
                      </a>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-slate-400 hidden sm:inline-block">
                    Added {new Date(client.createdAt).toLocaleDateString()}
                  </span>
                  <Button variant="outline" size="sm" onClick={() => onEdit(client)} className="shrink-0">
                    <Edit className="w-4 h-4 mr-2" /> Manage
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t border-slate-100">
                <div>
                   <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Project History</p>
                   {client.projectHistory.length > 0 ? (
                     <div className="flex flex-wrap gap-2">
                       {client.projectHistory.map((proj, idx) => (
                         <span key={idx} className="inline-flex items-center px-2 py-1 rounded-md bg-brand-50 text-brand-700 text-xs font-medium border border-brand-100">
                           {proj}
                         </span>
                       ))}
                     </div>
                   ) : (
                     <p className="text-sm text-slate-400 italic">No history yet</p>
                   )}
                </div>
                
                <div>
                   <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1">
                     <FileText className="w-3 h-3" /> Notes
                   </p>
                   <p className="text-sm text-slate-600 bg-slate-50 p-3 rounded-lg border border-slate-100 min-h-[60px]">
                     {client.notes || <span className="text-slate-400 italic">No notes added.</span>}
                   </p>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-10 bg-slate-50 rounded-xl border border-dashed border-slate-200">
            <p className="text-slate-500">No clients found matching "{searchTerm}"</p>
          </div>
        )}
      </div>
    </div>
  );
};
