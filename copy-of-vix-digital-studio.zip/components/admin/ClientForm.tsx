import React, { useState, useEffect } from 'react';
import { Client } from '../../types';
import { Button } from '../ui/Button';
import { Plus, X, Trash2 } from 'lucide-react';

interface ClientFormProps {
  initialData?: Client;
  onSave: (client: Client) => void;
  onCancel: () => void;
}

export const ClientForm: React.FC<ClientFormProps> = ({ initialData, onSave, onCancel }) => {
  const [formData, setFormData] = useState<Client>({
    id: '',
    name: '',
    email: '',
    phone: '',
    projectHistory: [],
    notes: '',
    createdAt: new Date(),
  });

  const [newProject, setNewProject] = useState('');

  useEffect(() => {
    if (initialData) {
      setFormData(initialData);
    } else {
      setFormData({
        id: Math.random().toString(36).substr(2, 9),
        name: '',
        email: '',
        phone: '',
        projectHistory: [],
        notes: '',
        createdAt: new Date(),
      });
    }
  }, [initialData]);

  const handleChange = (field: keyof Client, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const addProject = () => {
    if (newProject.trim()) {
      setFormData(prev => ({
        ...prev,
        projectHistory: [...prev.projectHistory, newProject.trim()]
      }));
      setNewProject('');
    }
  };

  const removeProject = (index: number) => {
    setFormData(prev => ({
      ...prev,
      projectHistory: prev.projectHistory.filter((_, i) => i !== index)
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6 bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-xl font-bold text-slate-800">
          {initialData ? 'Edit Client' : 'Add New Client'}
        </h3>
        <button type="button" onClick={onCancel} className="text-slate-400 hover:text-slate-600">
          <X className="w-6 h-6" />
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Name</label>
          <input
            required
            type="text"
            value={formData.name}
            onChange={(e) => handleChange('name', e.target.value)}
            className="w-full rounded-lg border border-slate-200 px-4 py-2 focus:ring-2 focus:ring-brand-500 focus:outline-none"
            placeholder="Jane Doe"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Email</label>
          <input
            required
            type="email"
            value={formData.email}
            onChange={(e) => handleChange('email', e.target.value)}
            className="w-full rounded-lg border border-slate-200 px-4 py-2 focus:ring-2 focus:ring-brand-500 focus:outline-none"
            placeholder="jane@example.com"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Phone</label>
          <input
            type="tel"
            value={formData.phone}
            onChange={(e) => handleChange('phone', e.target.value)}
            className="w-full rounded-lg border border-slate-200 px-4 py-2 focus:ring-2 focus:ring-brand-500 focus:outline-none"
            placeholder="(555) 000-0000"
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-slate-700 mb-1">Internal Notes</label>
        <textarea
          value={formData.notes}
          onChange={(e) => handleChange('notes', e.target.value)}
          rows={3}
          className="w-full rounded-lg border border-slate-200 px-4 py-2 focus:ring-2 focus:ring-brand-500 focus:outline-none"
          placeholder="Preferences, requirements, or personality notes..."
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-slate-700 mb-2">Project History</label>
        <div className="flex gap-2 mb-3">
          <input
            type="text"
            value={newProject}
            onChange={(e) => setNewProject(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addProject())}
            className="flex-1 rounded-lg border border-slate-200 px-4 py-2 focus:ring-2 focus:ring-brand-500 focus:outline-none"
            placeholder="Add a past project..."
          />
          <Button type="button" onClick={addProject} variant="secondary">
            <Plus className="w-4 h-4" />
          </Button>
        </div>
        
        {formData.projectHistory.length > 0 ? (
          <ul className="space-y-2">
            {formData.projectHistory.map((project, idx) => (
              <li key={idx} className="flex items-center justify-between bg-slate-50 px-3 py-2 rounded-lg border border-slate-100 group">
                <span className="text-sm text-slate-700">{project}</span>
                <button
                  type="button"
                  onClick={() => removeProject(idx)}
                  className="text-slate-400 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-sm text-slate-400 italic">No past projects listed.</p>
        )}
      </div>

      <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
        <Button type="button" variant="ghost" onClick={onCancel}>Cancel</Button>
        <Button type="submit">Save Client</Button>
      </div>
    </form>
  );
};
