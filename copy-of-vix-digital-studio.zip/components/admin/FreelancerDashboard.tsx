import React, { useState } from 'react';
import { Client } from '../../types';
import { MOCK_CLIENTS } from '../../constants';
import { ClientList } from './ClientList';
import { ClientForm } from './ClientForm';
import { Button } from '../ui/Button';
import { Users, Plus, LayoutDashboard } from 'lucide-react';

export const FreelancerDashboard: React.FC = () => {
  const [clients, setClients] = useState<Client[]>(MOCK_CLIENTS);
  const [view, setView] = useState<'list' | 'form'>('list');
  const [editingClient, setEditingClient] = useState<Client | undefined>(undefined);

  const handleAddClick = () => {
    setEditingClient(undefined);
    setView('form');
  };

  const handleEditClick = (client: Client) => {
    setEditingClient(client);
    setView('form');
  };

  const handleDeleteClient = (id: string) => {
    if (window.confirm('Are you sure you want to delete this client?')) {
        setClients(prev => prev.filter(c => c.id !== id));
    }
  };

  const handleSaveClient = (client: Client) => {
    if (editingClient) {
      // Update existing
      setClients(prev => prev.map(c => c.id === client.id ? client : c));
    } else {
      // Add new
      setClients(prev => [...prev, client]);
    }
    setView('list');
    setEditingClient(undefined);
  };

  return (
    <div className="min-h-screen bg-slate-50 font-sans">
      <div className="bg-gradient-to-r from-slate-900 to-indigo-900 text-white pb-24 pt-10 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
        {/* Abstract shapes in dashboard header */}
        <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-purple-500/20 rounded-full blur-[80px] -translate-y-1/2 translate-x-1/2" />
        <div className="absolute bottom-0 left-0 w-[300px] h-[300px] bg-blue-500/20 rounded-full blur-[60px] translate-y-1/2 -translate-x-1/2" />
        
        <div className="max-w-5xl mx-auto relative z-10">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-4">
               <div className="bg-white/10 backdrop-blur-md p-3 rounded-xl border border-white/10 shadow-lg">
                 <LayoutDashboard className="w-6 h-6 text-white" />
               </div>
               <div>
                 <h1 className="text-3xl font-bold font-heading">Freelancer Dashboard</h1>
                 <p className="text-indigo-200 text-sm mt-1">Manage your business & clients</p>
               </div>
            </div>
          </div>
          
          <div className="flex space-x-1 bg-white/10 backdrop-blur-sm p-1 rounded-lg inline-flex border border-white/5">
            <button className="px-4 py-2 rounded-md bg-white text-slate-900 text-sm font-bold shadow-sm transition-all">
                Clients
            </button>
            <button className="px-4 py-2 rounded-md text-indigo-200 hover:text-white hover:bg-white/5 text-sm font-medium transition-colors">
                Bookings (Coming Soon)
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 -mt-16 relative z-10">
        <div className="bg-white rounded-2xl shadow-xl shadow-slate-200/50 border border-slate-100 overflow-hidden min-h-[600px]">
           <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-white">
              <div className="flex items-center gap-2">
                <Users className="w-5 h-5 text-brand-600" />
                <h2 className="text-lg font-bold text-slate-800">Client Management</h2>
                <span className="bg-indigo-50 text-indigo-600 px-2.5 py-0.5 rounded-full text-xs font-bold border border-indigo-100">
                    {clients.length}
                </span>
              </div>
              
              {view === 'list' && (
                <Button onClick={handleAddClick} className="gap-2 rounded-xl shadow-md shadow-brand-500/20">
                    <Plus className="w-4 h-4" /> Add Client
                </Button>
              )}
           </div>

           <div className="p-6 bg-slate-50/50 min-h-full h-full">
              {view === 'list' ? (
                  <ClientList 
                    clients={clients} 
                    onEdit={handleEditClick} 
                    onDelete={handleDeleteClient} 
                  />
              ) : (
                  <div className="max-w-2xl mx-auto">
                    <ClientForm 
                        initialData={editingClient} 
                        onSave={handleSaveClient} 
                        onCancel={() => setView('list')} 
                    />
                  </div>
              )}
           </div>
        </div>
      </div>
    </div>
  );
};