
import React from 'react';
import { Star, Quote } from 'lucide-react';
import { TESTIMONIALS } from '../constants';

export const Reviews: React.FC = () => {
  return (
    <div className="py-16">
      <div className="text-center mb-12">
        <h2 className="text-3xl font-bold text-slate-900 font-heading mb-4">Client Success Stories</h2>
        <p className="text-slate-600 max-w-2xl mx-auto">Don't just take our word for it. Here's what our partners say about working with vix Studio.</p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {TESTIMONIALS.map((review) => (
          <div key={review.id} className="bg-white p-8 rounded-2xl shadow-lg border border-slate-100 relative group hover:-translate-y-1 transition-transform duration-300">
            <Quote className="absolute top-6 right-6 w-8 h-8 text-brand-100 group-hover:text-brand-200 transition-colors" />
            <div className="flex gap-1 mb-4">
              {[...Array(review.rating)].map((_, i) => (
                <Star key={i} className="w-4 h-4 text-amber-400 fill-amber-400" />
              ))}
            </div>
            <p className="text-slate-700 mb-6 leading-relaxed italic">"{review.content}"</p>
            <div className="flex items-center gap-4">
              <img src={review.avatarUrl} alt={review.clientName} className="w-12 h-12 rounded-full object-cover ring-2 ring-slate-100 group-hover:ring-brand-200 transition-all" />
              <div>
                <p className="font-bold text-slate-900 text-sm">{review.clientName}</p>
                <p className="text-slate-500 text-xs font-medium uppercase tracking-wide">{review.company}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
