
import React, { useState } from 'react';
import { SERVICES } from '../constants';
import { ServiceType, ServicePackage } from '../types';
import { Layout, Code, BookOpen, Feather, Check, ArrowRight, ShoppingBag, Store, ChevronDown, ChevronUp, HelpCircle } from 'lucide-react';

interface ServiceSelectionProps {
  selectedServiceId: string | null;
  onSelect: (id: string) => void;
}

const IconMap: Record<string, React.FC<any>> = {
  Layout,
  Code,
  BookOpen,
  Feather,
  ShoppingBag,
  Store
};

const ServiceCard: React.FC<{ 
  service: ServicePackage; 
  isSelected: boolean; 
  onSelect: (id: string) => void; 
}> = ({ service, isSelected, onSelect }) => {
  const [showFaq, setShowFaq] = useState(false);
  const Icon = IconMap[service.iconName] || Layout;

  return (
    <div
      onClick={(e) => {
        // Prevent triggering selection when clicking FAQ toggle
        if ((e.target as HTMLElement).closest('.faq-toggle')) return;
        onSelect(service.id);
      }}
      className={`
        relative group cursor-pointer rounded-3xl overflow-hidden transition-all duration-500 flex flex-col
        ${isSelected 
          ? 'ring-4 ring-brand-500 shadow-2xl scale-[1.02]' 
          : 'shadow-lg hover:shadow-2xl hover:-translate-y-2'
        }
      `}
    >
      {/* Image Header */}
      <div className="h-48 relative overflow-hidden shrink-0">
          <div className="absolute inset-0 bg-slate-900/30 group-hover:bg-slate-900/10 transition-colors z-10" />
          <img 
              src={service.imageUrl} 
              alt={service.title}
              className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700" 
          />
          
          {isSelected && (
            <div className="absolute top-4 right-4 z-20 bg-brand-600 text-white p-2 rounded-full shadow-lg">
              <Check className="w-5 h-5" />
            </div>
          )}
      </div>

      {/* Content Body */}
      <div className={`p-8 bg-white relative z-20 flex flex-col flex-1`}>
          <div className="flex items-start justify-between mb-4">
              <div className={`p-3 rounded-2xl ${isSelected ? 'bg-brand-600 text-white' : 'bg-brand-50 text-brand-600'}`}>
                  <Icon className="w-6 h-6" />
              </div>
              <span className="font-bold text-lg text-slate-900">{service.priceRange}</span>
          </div>

          <h3 className="text-2xl font-bold text-slate-900 mb-3 font-heading">{service.title}</h3>
          <p className="text-slate-600 text-sm mb-6 leading-relaxed line-clamp-3">{service.description}</p>
          
          <ul className="space-y-3 mb-6">
            {service.features.slice(0, 3).map((feature, idx) => (
                <li key={idx} className="flex items-center gap-3 text-sm text-slate-600">
                <div className="w-1.5 h-1.5 rounded-full bg-brand-400 shrink-0" />
                {feature}
                </li>
            ))}
          </ul>

          <div className="mt-auto space-y-4">
             {/* FAQ Toggle */}
             {service.faqs && service.faqs.length > 0 && (
               <div className="border-t border-slate-100 pt-4">
                  <button 
                    onClick={() => setShowFaq(!showFaq)}
                    className="faq-toggle w-full flex items-center justify-between text-xs font-bold text-slate-500 hover:text-brand-600 uppercase tracking-wide py-2"
                  >
                     <span className="flex items-center gap-2"><HelpCircle className="w-4 h-4" /> FAQ</span>
                     {showFaq ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  </button>
                  
                  {showFaq && (
                    <div className="mt-3 space-y-4 animate-fade-in-up">
                      {service.faqs.map((faq, i) => (
                        <div key={i} className="text-left bg-slate-50 p-3 rounded-xl">
                          <p className="text-xs font-bold text-slate-800 mb-1">{faq.question}</p>
                          <p className="text-xs text-slate-600 leading-relaxed">{faq.answer}</p>
                        </div>
                      ))}
                    </div>
                  )}
               </div>
             )}

             <button className={`
                w-full py-3 px-4 rounded-xl font-semibold text-sm flex items-center justify-center gap-2 transition-colors
                ${isSelected 
                    ? 'bg-slate-900 text-white' 
                    : 'bg-slate-100 text-slate-700 group-hover:bg-brand-600 group-hover:text-white'}
             `}>
                {isSelected ? 'Selected' : 'Select Package'} 
                {!isSelected && <ArrowRight className="w-4 h-4" />}
             </button>
          </div>
      </div>
    </div>
  );
};

export const ServiceSelection: React.FC<ServiceSelectionProps> = ({ selectedServiceId, onSelect }) => {
  const [activeFilter, setActiveFilter] = useState<ServiceType | 'ALL'>('ALL');

  const filters: { id: ServiceType | 'ALL'; label: string }[] = [
    { id: 'ALL', label: 'All Services' },
    { id: 'WEB_DEV', label: 'Web Development' },
    { id: 'ECOMMERCE', label: 'E-commerce' },
    { id: 'EBOOK_WRITING', label: 'Ebook Writing' },
  ];

  const filteredServices = SERVICES.filter(
    (service) => activeFilter === 'ALL' || service.type === activeFilter
  );

  return (
    <div className="space-y-8">
      {/* Filter Tabs */}
      <div className="flex flex-wrap justify-center gap-3">
        {filters.map((filter) => (
          <button
            key={filter.id}
            onClick={() => setActiveFilter(filter.id)}
            className={`
              px-5 py-2.5 rounded-full text-sm font-bold transition-all duration-300 shadow-sm
              ${activeFilter === filter.id
                ? 'bg-slate-900 text-white shadow-slate-900/20 shadow-lg scale-105 ring-2 ring-slate-900 ring-offset-2'
                : 'bg-white text-slate-500 hover:bg-slate-50 hover:text-brand-600 border border-slate-200'
              }
            `}
          >
            {filter.label}
          </button>
        ))}
      </div>

      {/* Services Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
        {filteredServices.map((service) => (
            <ServiceCard 
              key={service.id} 
              service={service} 
              isSelected={selectedServiceId === service.id} 
              onSelect={onSelect} 
            />
        ))}
      </div>
      
      {filteredServices.length === 0 && (
         <div className="text-center py-12 bg-white rounded-3xl border border-dashed border-slate-300">
            <p className="text-slate-400">No services found in this category.</p>
         </div>
      )}
    </div>
  );
};
