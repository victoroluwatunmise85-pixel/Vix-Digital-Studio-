
import React from 'react';
import { ExternalLink, ArrowRight } from 'lucide-react';
import { PORTFOLIO_ITEMS } from '../constants';

export const Portfolio: React.FC = () => {
  return (
    <div className="animate-fade-in-up pb-16 pt-8 max-w-6xl mx-auto px-4">
       <div className="text-center mb-16">
          <span className="inline-block py-1.5 px-4 rounded-full bg-brand-50 text-brand-600 text-xs font-bold uppercase tracking-wider mb-4 border border-brand-100">
             Featured Projects
          </span>
          <h2 className="text-4xl md:text-5xl font-extrabold text-slate-900 font-heading mb-6">Our Selected Work</h2>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto">
             A showcase of e-commerce platforms, brand identities, and digital experiences we've crafted for world-class clients.
          </p>
       </div>

       <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {PORTFOLIO_ITEMS.map((item) => (
             <div key={item.id} className="group relative bg-white rounded-3xl overflow-hidden shadow-xl hover:shadow-2xl transition-all duration-500 hover:-translate-y-2">
                <div className="relative h-64 overflow-hidden">
                   <div className="absolute inset-0 bg-slate-900/0 group-hover:bg-slate-900/40 transition-colors z-10 duration-300" />
                   <img 
                     src={item.imageUrl} 
                     alt={item.title} 
                     className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700"
                   />
                   <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity z-20 duration-300">
                      <a 
                        href={item.websiteUrl} 
                        target="_blank" 
                        rel="noreferrer"
                        className="bg-white text-slate-900 px-6 py-3 rounded-full font-bold flex items-center gap-2 transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300 shadow-xl hover:bg-brand-50"
                      >
                         Visit Website <ExternalLink className="w-4 h-4" />
                      </a>
                   </div>
                </div>
                <div className="p-8">
                   <p className="text-xs font-bold text-brand-600 uppercase tracking-widest mb-2">{item.category}</p>
                   <h3 className="text-2xl font-bold text-slate-900 flex items-center justify-between group-hover:text-brand-600 transition-colors">
                      {item.title}
                      <ArrowRight className="w-6 h-6 -rotate-45 group-hover:rotate-0 transition-transform duration-300 text-slate-300 group-hover:text-brand-600" />
                   </h3>
                </div>
             </div>
          ))}
       </div>
    </div>
  );
};
