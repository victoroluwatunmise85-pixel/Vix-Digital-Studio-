import React, { useState } from 'react';
import { analyzeProjectRequest } from '../services/geminiService';
import { SERVICES } from '../constants';
import { AiAnalysisResult } from '../types';
import { Button } from './ui/Button';
import { Sparkles, ArrowRight, CheckCircle, BrainCircuit } from 'lucide-react';

interface AiConsultantProps {
  onRecommendationAccepted: (serviceId: string, description: string) => void;
}

export const AiConsultant: React.FC<AiConsultantProps> = ({ onRecommendationAccepted }) => {
  const [description, setDescription] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<AiAnalysisResult | null>(null);

  const handleAnalyze = async () => {
    if (!description.trim()) return;
    setIsAnalyzing(true);
    setResult(null); // Reset previous result
    try {
      const analysis = await analyzeProjectRequest(description, SERVICES);
      setResult(analysis);
    } catch (error) {
      console.error(error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="glass-panel rounded-3xl p-8 shadow-xl relative overflow-hidden mb-12 border-t border-white/60">
      {/* Decorative gradient glow */}
      <div className="absolute top-0 right-0 -mt-10 -mr-10 w-40 h-40 bg-brand-400/20 rounded-full blur-3xl pointer-events-none"></div>

      <div className="relative z-10">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2.5 bg-gradient-to-br from-brand-500 to-indigo-600 rounded-xl shadow-lg shadow-brand-500/20">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-slate-900 font-heading">AI Project Consultant</h3>
            <p className="text-sm text-slate-500 font-medium">Describe your vision, and we'll scope it for you.</p>
          </div>
        </div>

        <div className="space-y-6">
          <div className="relative">
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="e.g. I need a modern landing page for my bakery that allows customers to order sourdough online..."
              className="w-full min-h-[120px] p-5 rounded-2xl bg-white/50 border border-slate-200 focus:border-brand-500 focus:ring-4 focus:ring-brand-500/10 transition-all text-slate-700 placeholder:text-slate-400 resize-y text-base shadow-inner"
            />
            {description.length === 0 && (
                <div className="absolute top-5 left-5 pointer-events-none text-slate-400">
                    <span className="opacity-50">Try: </span>
                    <span className="italic opacity-70">"I want to write a technical ebook about React hooks..."</span>
                </div>
            )}
          </div>

          {!result && !isAnalyzing && (
              <div className="flex justify-end">
                <Button 
                onClick={handleAnalyze} 
                disabled={!description.trim()}
                className="rounded-xl px-6 py-3 bg-slate-900 hover:bg-slate-800 text-white shadow-lg transition-transform active:scale-95"
                >
                <BrainCircuit className="w-4 h-4 mr-2" /> Analyze Request
                </Button>
            </div>
          )}
          
          {isAnalyzing && (
            <div className="animate-pulse flex flex-col items-center justify-center py-8 space-y-3">
                <div className="w-12 h-12 rounded-full border-4 border-brand-200 border-t-brand-600 animate-spin"></div>
                <p className="text-sm font-semibold text-brand-600 animate-pulse">Consulting AI Knowledge Base...</p>
            </div>
          )}

          {result && (
            <div className="animate-fade-in-up bg-white/60 backdrop-blur-md rounded-2xl p-6 border border-white shadow-lg ring-1 ring-slate-100">
              <div className="flex flex-col md:flex-row gap-6">
                <div className="flex-1">
                    <h4 className="font-bold text-slate-900 mb-3 flex items-center gap-2 text-lg">
                        <span className="text-2xl">💡</span> Analysis
                    </h4>
                    <p className="text-slate-700 leading-relaxed mb-4">{result.analysis}</p>
                    
                    <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-indigo-50 border border-indigo-100 text-indigo-700 text-sm font-bold">
                        <span className="text-lg">⏱️</span> Est. Timeline: {result.estimatedTimeline}
                    </div>
                </div>
                
                <div className="md:w-1/3 bg-white/50 rounded-xl p-4 border border-slate-100">
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">Suggested Next Steps</p>
                    <ul className="space-y-3">
                        {result.suggestedNextSteps.map((step, idx) => (
                            <li key={idx} className="flex items-start gap-2 text-sm text-slate-600">
                                <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 shrink-0" />
                                <span className="leading-tight">{step}</span>
                            </li>
                        ))}
                    </ul>
                </div>
              </div>
              
              <div className="mt-6 pt-5 border-t border-slate-200/60 flex flex-col sm:flex-row justify-between items-center gap-4">
                  <div>
                      <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">Recommended Service</span>
                      <span className="text-lg font-bold text-brand-700">
                        {SERVICES.find(s => s.id === result.recommendedServiceId)?.title || 'Custom Service'}
                      </span>
                  </div>
                  <div className="flex gap-3">
                    <button 
                        onClick={() => setResult(null)} 
                        className="px-4 py-2 text-sm font-medium text-slate-500 hover:text-slate-800 transition-colors"
                    >
                        Reset
                    </button>
                    <Button 
                        onClick={() => onRecommendationAccepted(result.recommendedServiceId, description)}
                        className="gap-2 rounded-xl shadow-brand-500/20 shadow-lg"
                    >
                        Book Recommendation <ArrowRight className="w-4 h-4" />
                    </Button>
                  </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};