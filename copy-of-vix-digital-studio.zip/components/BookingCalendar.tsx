import React, { useState, useEffect } from 'react';
import { BookingSlot } from '../types';
import { ChevronLeft, ChevronRight, Clock } from 'lucide-react';

interface BookingCalendarProps {
  onSlotSelect: (slot: BookingSlot) => void;
  selectedSlot?: BookingSlot;
}

export const BookingCalendar: React.FC<BookingCalendarProps> = ({ onSlotSelect, selectedSlot }) => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  
  // Generate next 14 days
  const getDays = (startDate: Date) => {
    const days = [];
    for (let i = 0; i < 14; i++) {
      const date = new Date(startDate);
      date.setDate(startDate.getDate() + i);
      days.push(date);
    }
    return days;
  };

  const days = getDays(new Date());

  // Mock time slots
  const generateTimeSlots = (date: Date) => {
    // Randomize availability for demo
    const times = ['09:00 AM', '10:00 AM', '11:00 AM', '01:00 PM', '02:00 PM', '03:30 PM', '05:00 PM'];
    return times.map(time => ({
      date: date,
      time,
      available: Math.random() > 0.3 // 70% chance available
    }));
  };

  const [activeSlots, setActiveSlots] = useState<BookingSlot[]>([]);

  useEffect(() => {
    if (selectedDate) {
      setActiveSlots(generateTimeSlots(selectedDate));
    }
  }, [selectedDate]);

  // Format helpers
  const formatDay = (d: Date) => d.toLocaleDateString('en-US', { weekday: 'short' });
  const formatNum = (d: Date) => d.getDate();
  const formatMonth = (d: Date) => d.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });

  return (
    <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
      <div className="p-4 border-b border-slate-100 bg-slate-50 flex items-center justify-between">
        <h3 className="font-semibold text-slate-800">Select Date & Time</h3>
        <div className="text-sm text-slate-500">{formatMonth(currentDate)}</div>
      </div>

      <div className="p-6">
        {/* Date Scroller */}
        <div className="flex gap-3 overflow-x-auto pb-4 no-scrollbar">
          {days.map((day, idx) => {
             const isSelected = selectedDate?.toDateString() === day.toDateString();
             const isToday = day.toDateString() === new Date().toDateString();
             
             return (
               <button
                 key={idx}
                 onClick={() => setSelectedDate(day)}
                 className={`
                    flex flex-col items-center justify-center min-w-[70px] h-20 rounded-xl border transition-all
                    ${isSelected 
                      ? 'bg-brand-600 border-brand-600 text-white shadow-md transform scale-105' 
                      : 'bg-white border-slate-200 text-slate-600 hover:border-brand-300 hover:bg-brand-50'
                    }
                 `}
               >
                 <span className={`text-xs font-medium uppercase mb-1 ${isSelected ? 'text-brand-100' : 'text-slate-400'}`}>
                    {isToday ? 'Today' : formatDay(day)}
                 </span>
                 <span className="text-xl font-bold">{formatNum(day)}</span>
               </button>
             );
          })}
        </div>

        {/* Time Slots */}
        <div className="mt-6">
          {!selectedDate ? (
            <div className="text-center py-8 text-slate-400 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                <Clock className="w-8 h-8 mx-auto mb-2 opacity-50" />
                <p>Select a date above to see available times</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
              {activeSlots.map((slot, idx) => {
                const isSlotSelected = selectedSlot?.time === slot.time && selectedSlot.date.toDateString() === selectedDate.toDateString();
                
                return (
                  <button
                    key={idx}
                    disabled={!slot.available}
                    onClick={() => onSlotSelect(slot)}
                    className={`
                      py-2 px-3 rounded-lg text-sm font-medium border transition-all
                      ${!slot.available 
                        ? 'bg-slate-50 text-slate-300 border-slate-100 cursor-not-allowed decoration-slate-300' 
                        : isSlotSelected
                            ? 'bg-brand-600 text-white border-brand-600 shadow-md'
                            : 'bg-white text-slate-700 border-slate-200 hover:border-brand-500 hover:text-brand-600'
                      }
                    `}
                  >
                    {slot.time}
                  </button>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
