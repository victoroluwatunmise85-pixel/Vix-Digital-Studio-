import { GoogleGenAI, Type } from "@google/genai";
import { AiAnalysisResult, ServicePackage } from "../types";

// Initialize Gemini Client
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const analyzeProjectRequest = async (
  userDescription: string,
  availableServices: ServicePackage[]
): Promise<AiAnalysisResult> => {
  const model = "gemini-2.5-flash";

  const servicesContext = availableServices
    .map((s) => `- ID: ${s.id}, Title: ${s.title}, Type: ${s.type}, Price: ${s.priceRange}, Features: ${s.features.join(', ')}. Desc: ${s.description}`)
    .join("\n");

  const prompt = `
    You are the Senior AI Consultant for 'vix Digital Studio', a premium digital agency.
    A potential client has described their project needs: "${userDescription}".
    
    Here are the premium services we offer:
    ${servicesContext}

    Analyze the request deeply.
    1. Identify the core need and technical requirements.
    2. Match it to the most appropriate service ID. If the request is vague, recommend the service that offers the best starting point (usually a consultation or the smaller package).
    3. Estimate a realistic timeline based on industry standards.
    4. Suggest 3 concrete, professional next steps for the client.
    
    Return the response in JSON format.
  `;

  try {
    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
      config: {
        thinkingConfig: { thinkingBudget: 1024 }, // Enable thinking for better matching
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            recommendedServiceId: { type: Type.STRING },
            analysis: { type: Type.STRING },
            estimatedTimeline: { type: Type.STRING },
            suggestedNextSteps: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
          },
          required: ["recommendedServiceId", "analysis", "estimatedTimeline", "suggestedNextSteps"],
        },
      },
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");
    
    return JSON.parse(text) as AiAnalysisResult;
  } catch (error) {
    console.error("Error analyzing project:", error);
    // Fallback in case of API error
    return {
      recommendedServiceId: availableServices[0].id,
      analysis: "We couldn't analyze your request automatically, but we'd love to discuss it further. Based on general needs, this service might be a good start.",
      estimatedTimeline: "To be discussed",
      suggestedNextSteps: ["Book a discovery call", "Prepare your requirements document", "Gather visual inspiration"],
    };
  }
};