
import { ServicePackage, Client, PortfolioItem, Testimonial } from './types';

export const SERVICES: ServicePackage[] = [
  {
    id: 'web-landing',
    type: 'WEB_DEV',
    title: 'High-Conversion Landing Page',
    description: 'Stop losing customers with a generic site. We build custom, high-performance landing pages scientifically designed to convert visitors into leads. Includes professional copywriting, premium stock assets, and rigorous speed optimization to ensure instant loading.',
    priceRange: '$500 - $1,000',
    features: ['Custom UI/UX Design', 'Conversion Copywriting', 'Mobile-First Responsiveness', 'SEO Fundamentals', 'Mailchimp/CRM Integration', 'Speed Optimization (90+ Score)'],
    iconName: 'Layout',
    imageUrl: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=800',
    faqs: [
      {
        question: "What platform do you build on?",
        answer: "We typically use React/Next.js for maximum performance and flexibility, but we can also build on WordPress or Webflow if you require a CMS."
      },
      {
        question: "How long does it take?",
        answer: "Most landing pages are designed, developed, and launched within 5-7 business days, depending on how quickly we receive feedback."
      },
      {
        question: "Do you write the text content?",
        answer: "Yes! Professional conversion copywriting is included to ensure your message resonates with your audience."
      }
    ]
  },
  {
    id: 'web-app',
    type: 'WEB_DEV',
    title: 'Scalable Full Stack Application',
    description: 'Launch your SaaS or complex web platform with confidence. We provide end-to-end development using modern frameworks like React and Next.js. You get a secure, scalable application complete with user authentication, database management, and an intuitive admin dashboard.',
    priceRange: '$2,000 - $5,000+',
    features: ['React/Next.js Architecture', 'Secure Auth (OAuth/Email)', 'PostgreSQL/MongoDB Database', 'Admin Dashboard Panel', 'Stripe/Payment Integration', 'Cloud Deployment (Vercel/AWS)'],
    iconName: 'Code',
    imageUrl: 'https://images.unsplash.com/photo-1555099962-4199c345e5dd?auto=format&fit=crop&q=80&w=800',
    faqs: [
      {
        question: "Is hosting included in the price?",
        answer: "We set up the hosting infrastructure (usually Vercel or AWS), but the monthly hosting costs are paid directly to the provider. We'll help you select the most cost-effective tier."
      },
      {
        question: "Do you provide post-launch support?",
        answer: "Yes, we include 30 days of critical bug fixes and support. Ongoing maintenance packages are available separately."
      },
      {
        question: "Who owns the code?",
        answer: "You do. Upon final payment, 100% of the intellectual property and source code is transferred to you."
      }
    ]
  },
  {
    id: 'shopify-store',
    type: 'ECOMMERCE',
    title: 'Premium Shopify Store Launch',
    description: 'Get a turnkey e-commerce business. We handle everything from store setup and theme customization to product upload and payment configuration. We optimize your store structure for SEO and sales, ensuring you are ready to sell from day one.',
    priceRange: '$1,500 - $3,500',
    features: ['Premium Theme Customization', 'Conversion Rate Optimization', 'App Ecosystem Setup', 'Payment & Shipping Config', '50+ Product Imports', 'Automated Email Flows'],
    iconName: 'ShoppingBag',
    imageUrl: 'https://images.unsplash.com/photo-1556742031-c6961e8560b0?auto=format&fit=crop&q=80&w=800',
    faqs: [
      {
        question: "Do I need to pay for a Shopify theme?",
        answer: "We can work with free themes or customize premium themes. If you choose a premium theme, the license cost (usually ~$180-$350) is separate."
      },
      {
        question: "Can you migrate my store from Etsy/WooCommerce?",
        answer: "Absolutely. We can import your products, customer data, and order history from your previous platform."
      },
      {
        question: "Will I know how to use it?",
        answer: "Yes, we provide a recorded training session showing you how to manage orders, add products, and update content."
      }
    ]
  },
  {
    id: 'facebook-shop',
    type: 'ECOMMERCE',
    title: 'Facebook Shop Setup',
    description: 'Tap into billions of active users. We set up your professional Facebook Shop, sync it with your catalog, and configure the Commerce Manager so you can tag products in posts and run dynamic ads seamlessly.',
    priceRange: '$400 - $800',
    features: ['Commerce Manager Setup', 'Catalog Synchronization', 'Shop Customization', 'Pixel Integration', 'Checkout Configuration', 'Domain Verification'],
    iconName: 'Store',
    imageUrl: 'https://images.unsplash.com/photo-1562577309-4932fdd64cd1?auto=format&fit=crop&q=80&w=800',
    faqs: [
      {
        question: "Do I need a website first?",
        answer: "It is highly recommended to have a website to sync products from, but you can also manage a catalog manually within Commerce Manager."
      },
      {
        question: "Why was my shop rejected before?",
        answer: "Common reasons include domain verification issues or policy violations. We audit your assets to ensure compliance before submission."
      }
    ]
  },
  {
    id: 'instagram-shop',
    type: 'ECOMMERCE',
    title: 'Instagram Shopping Integration',
    description: 'Turn your feed into a storefront. We enable Instagram Shopping for your brand, allowing you to tag products in stories and posts. We handle the approval process and ensure your aesthetic matches your brand identity.',
    priceRange: '$400 - $800',
    features: ['Account Approval Handling', 'Product Tagging Setup', 'Instagram Shop Tab Design', 'Story Product Stickers', 'Influencer Tagging Setup', 'Insights Dashboard Tour'],
    iconName: 'Store',
    imageUrl: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?auto=format&fit=crop&q=80&w=800',
    faqs: [
      {
        question: "Can I sell without a website?",
        answer: "Instagram primarily requires a domain you own to verify the shop. We can help you set up a simple landing page if you don't have a full store."
      },
      {
        question: "Does this include content creation?",
        answer: "This service focuses on the technical setup and shop configuration. We have separate packages for social media content creation."
      }
    ]
  },
  {
    id: 'tiktok-shop',
    type: 'ECOMMERCE',
    title: 'TikTok Shop Launch',
    description: 'Ride the wave of social commerce. We set up your TikTok Shop Seller Center, optimize your product listings for the algorithm, and integrate it with your existing inventory. Start selling directly in the app.',
    priceRange: '$500 - $1,000',
    features: ['Seller Center Registration', 'Product Listing Optimization', 'Affiliate Center Setup', 'Order Management Training', 'Live Shopping Configuration', 'TikTok Ads Pixel Setup'],
    iconName: 'Store',
    imageUrl: 'https://images.unsplash.com/photo-1611162618071-b39a2ec055fb?auto=format&fit=crop&q=80&w=800',
    faqs: [
      {
        question: "How long does approval take?",
        answer: "TikTok Seller Center approval usually takes 1-3 business days. We ensure all documents are submitted correctly to avoid delays."
      },
      {
        question: "Can I use dropshipping?",
        answer: "TikTok has strict shipping speed requirements. We will advise you on whether your fulfillment method meets their SLAs."
      }
    ]
  },
  {
    id: 'ebook-standard',
    type: 'EBOOK_WRITING',
    title: 'Lead Magnet Ebook (10k Words)',
    description: 'Generate leads on autopilot. We ghostwrite a compelling, well-researched ebook tailored to your niche. You get a polished manuscript plus a professional cover design, formatted perfectly for PDF distribution or Amazon KDP.',
    priceRange: '$800 - $1,500',
    features: ['Niche Market Research', 'Compelling Title Ideation', 'Professional Editing', 'Custom Cover Design', 'Lead Magnet Strategy', 'Copyright Transfer'],
    iconName: 'BookOpen',
    imageUrl: 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?auto=format&fit=crop&q=80&w=800',
    faqs: [
      {
        question: "Do I own the copyright?",
        answer: "Yes. Once the project is complete and paid for, you own full rights to the content and can publish it under your name."
      },
      {
        question: "What niches do you write for?",
        answer: "We have experience in tech, business, self-help, and health. If your topic is highly specialized, we'll research it thoroughly."
      }
    ]
  },
  {
    id: 'ebook-premium',
    type: 'EBOOK_WRITING',
    title: 'Authority Book (20k+ Words)',
    description: 'Establish yourself as an industry thought leader. We work with you to craft a comprehensive book that showcases your expertise. Includes deep research, interviews, advanced formatting, and a launch strategy guide.',
    priceRange: '$2,500+',
    features: ['Deep-Dive Industry Research', 'Interview-Based Ghostwriting', 'Premium Cover Art', 'KDP & IngramSpark Formatting', 'Author Bio & Blurb Writing', 'Launch Marketing Plan'],
    iconName: 'Feather',
    imageUrl: 'https://images.unsplash.com/photo-1550399105-c4db5fb85c18?auto=format&fit=crop&q=80&w=800',
    faqs: [
      {
        question: "How does the interview process work?",
        answer: "We schedule 2-3 calls to capture your voice, stories, and expertise, which form the backbone of the book."
      },
      {
        question: "Do you handle Amazon publishing?",
        answer: "We provide the formatted files ready for upload and guide you through the KDP submission process."
      }
    ]
  },
];

export const MOCK_CLIENTS: Client[] = [
  {
    id: '1',
    name: 'Alice Freeman',
    email: 'alice@example.com',
    phone: '(555) 123-4567',
    projectHistory: ['Bakery Landing Page', 'Sourdough Recipes Ebook'],
    notes: 'Prefers communication via email. Likes pastel color palettes.',
    createdAt: new Date('2023-11-15'),
  },
  {
    id: '2',
    name: 'Marcus Chen',
    email: 'marcus@techstart.io',
    phone: '(555) 987-6543',
    projectHistory: ['SaaS Dashboard MVP', 'API Documentation Review'],
    notes: 'Strict deadlines, very technical. Use Slack for quick updates.',
    createdAt: new Date('2024-01-10'),
  },
  {
    id: '3',
    name: 'Sarah Johnson',
    email: 'sarah.j@creative.net',
    phone: '(555) 456-7890',
    projectHistory: [],
    notes: 'New inquiry from LinkedIn. Interested in a personal portfolio.',
    createdAt: new Date('2024-02-28'),
  }
];

export const PORTFOLIO_ITEMS: PortfolioItem[] = [
  {
    id: 'paccopet',
    title: 'Pacco Pet',
    category: 'E-commerce',
    imageUrl: 'https://images.unsplash.com/photo-1583337130417-3346a1be7dee?auto=format&fit=crop&q=80&w=800',
    websiteUrl: 'https://paccopet.com'
  },
  {
    id: 'gymshark',
    title: 'Gymshark',
    category: 'E-commerce / Branding',
    imageUrl: 'https://images.unsplash.com/photo-1517836357463-d25dfeac3438?auto=format&fit=crop&q=80&w=800',
    websiteUrl: 'https://gymshark.com'
  },
  {
    id: 'sparklytreats',
    title: 'Sparkly Treats',
    category: 'Jewelry E-commerce',
    imageUrl: 'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?auto=format&fit=crop&q=80&w=800',
    websiteUrl: 'https://sparklytreats.com'
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: '1',
    clientName: 'Emily Parker',
    company: 'The Sourdough Co.',
    content: "vix Studio completely transformed our online presence. The landing page they designed increased our conversion rate by 150% in the first month.",
    rating: 5,
    avatarUrl: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&q=80&w=150'
  },
  {
    id: '2',
    clientName: 'David Chen',
    company: 'TechFlow',
    content: "The technical ebook they wrote for us was a masterpiece. It established us as thought leaders in the AI space immediately.",
    rating: 5,
    avatarUrl: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=150'
  },
  {
    id: '3',
    clientName: 'Sarah Miller',
    company: 'Boutique Fitness',
    content: "Our Shopify store launch was flawless. They handled everything from inventory upload to payment gateway setup. Highly recommended!",
    rating: 5,
    avatarUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=150'
  }
];
