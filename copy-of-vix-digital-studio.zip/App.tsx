
import React, { useState, useEffect } from 'react';
import { ServiceSelection } from './components/ServiceSelection';
import { BookingCalendar } from './components/BookingCalendar';
import { BookingForm } from './components/BookingForm';
import { AiConsultant } from './components/AiConsultant';
import { Reviews } from './components/Reviews';
import { Portfolio } from './components/Portfolio';
import { Button } from './components/ui/Button';
import { FreelancerDashboard } from './components/admin/FreelancerDashboard';
import { UserBookingDetails, BookingSlot } from './types';
import { SERVICES } from './constants';
import { Check, Calendar, User, Briefcase, ArrowLeft, Shield, Sparkles, Instagram, Linkedin, Twitter, Download } from 'lucide-react';

// Steps: 1. Service, 2. Slot, 3. Details, 4. Confirm
type Step = 1 | 2 | 3 | 4;
type View = 'HOME' | 'PORTFOLIO' | 'ADMIN';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<View>('HOME');
  
  // Client App State
  const [step, setStep] = useState<Step>(1);
  const [details, setDetails] = useState<Partial<UserBookingDetails>>({});
  const [isLoading, setIsLoading] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);

  useEffect(() => {
    const handleBeforeInstallPrompt = (e: any) => {
      // Prevent the mini-infobar from appearing on mobile
      e.preventDefault();
      // Stash the event so it can be triggered later.
      setDeferredPrompt(e);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  const handleInstallClick = async () => {
    if (!deferredPrompt) return;
    // Show the install prompt
    deferredPrompt.prompt();
    // Wait for the user to respond to the prompt
    const { outcome } = await deferredPrompt.userChoice;
    console.log(`User response to the install prompt: ${outcome}`);
    setDeferredPrompt(null);
  };

  // Handlers
  const handleServiceSelect = (id: string, description?: string) => {
    setDetails(prev => ({ 
      ...prev, 
      serviceId: id,
      projectDescription: description || prev.projectDescription 
    }));
    // If coming from AI Consultant with description, auto-fill it
    setStep(2);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSlotSelect = (slot: BookingSlot) => {
    setDetails(prev => ({ ...prev, slot }));
  };

  const handleDetailsChange = (field: keyof UserBookingDetails, value: string) => {
    setDetails(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async () => {
    setIsLoading(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));
    setIsLoading(false);
    setStep(4);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const navigateToHome = () => {
    setCurrentView('HOME');
    setStep(1);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const selectedService = SERVICES.find(s => s.id === details.serviceId);

  // Render Helpers
  const renderStepIndicator = () => {
    const steps = [
      { num: 1, label: 'Service', icon: Briefcase },
      { num: 2, label: 'Schedule', icon: Calendar },
      { num: 3, label: 'Details', icon: User },
    ];
    
    return (
      <div className="flex items-center justify-center mb-12">
        {steps.map((s, idx) => {
          const isActive = step === s.num;
          const isCompleted = step > s.num;
          const Icon = s.icon;
          
          return (
            <div key={s.num} className="flex items-center">
              <div className="flex flex-col items-center relative z-10 group cursor-default">
                <div 
                  className={`
                    w-12 h-12 rounded-2xl flex items-center justify-center border-2 transition-all duration-300 shadow-sm
                    ${isActive ? 'border-brand-500 bg-brand-500 text-white shadow-brand-500/50 shadow-lg scale-110' : 
                      isCompleted ? 'border-brand-500 bg-white text-brand-600' : 'border-slate-200 bg-white text-slate-300'}
                  `}
                >
                  {isCompleted ? <Check className="w-6 h-6" /> : <Icon className="w-5 h-5" />}
                </div>
                <span className={`text-xs mt-3 font-bold uppercase tracking-wider ${isActive ? 'text-brand-600' : 'text-slate-400'}`}>
                  {s.label}
                </span>
              </div>
              {idx < steps.length - 1 && (
                <div className={`w-16 h-0.5 mx-4 -mt-8 transition-all duration-500 ${isCompleted ? 'bg-brand-500' : 'bg-slate-200'}`} />
              )}
            </div>
          );
        })}
      </div>
    );
  };

  if (currentView === 'ADMIN') {
    return (
      <>
        <FreelancerDashboard />
        <div className="fixed bottom-4 left-4 z-50">
          <button 
            onClick={navigateToHome}
            className="bg-slate-900 text-white px-4 py-2 rounded-full text-xs font-bold uppercase tracking-wide shadow-2xl hover:bg-slate-800 transition-all flex items-center gap-2"
          >
            <ArrowLeft className="w-3 h-3" /> Back to Studio
          </button>
        </div>
      </>
    );
  }

  return (
    <div className="min-h-screen bg-[#F8FAFC] relative font-sans text-slate-900 overflow-x-hidden">
      {/* Stylish Blue Purple Background */}
      <div className="fixed inset-0 z-0 overflow-hidden pointer-events-none">
         {/* Base Gradient */}
         <div className="absolute inset-0 bg-gradient-to-br from-indigo-50/80 via-purple-50/50 to-blue-50/80" />
         
         {/* Vivid Blobs */}
         <div className="absolute top-[-10%] right-[-5%] w-[600px] h-[600px] rounded-full bg-purple-500/20 blur-[120px] mix-blend-multiply animate-pulse" style={{animationDuration: '8s'}} />
         <div className="absolute top-[30%] left-[-15%] w-[500px] h-[500px] rounded-full bg-blue-500/20 blur-[100px] mix-blend-multiply animate-pulse" style={{animationDuration: '10s', animationDelay: '1s'}} />
         <div className="absolute bottom-[-10%] right-[10%] w-[600px] h-[600px] rounded-full bg-indigo-500/20 blur-[120px] mix-blend-multiply animate-pulse" style={{animationDuration: '12s', animationDelay: '2s'}} />
         <div className="absolute bottom-[20%] left-[20%] w-[300px] h-[300px] rounded-full bg-violet-400/20 blur-[80px] mix-blend-multiply" />

         {/* Background noise texture */}
         <div className="absolute inset-0 opacity-[0.04]" style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")` }}></div>
      </div>

      {/* Header */}
      <header className="fixed w-full top-0 z-40 glass-header border-b border-white/40 transition-all duration-300">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
            <div className="flex items-center gap-3 group cursor-pointer" onClick={navigateToHome}>
                <div className="w-10 h-10 bg-gradient-to-br from-brand-600 to-indigo-700 rounded-xl flex items-center justify-center shadow-lg group-hover:shadow-brand-500/30 transition-shadow">
                    <span className="text-white font-extrabold text-xl font-heading">v</span>
                </div>
                <div className="flex flex-col">
                    <h1 className="text-xl font-bold text-slate-900 tracking-tight leading-none font-heading">vix<span className="text-brand-600">.</span></h1>
                    <span className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em] leading-tight">Digital Studio</span>
                </div>
            </div>
            
            <div className="hidden md:flex items-center gap-6">
                <button 
                  onClick={navigateToHome}
                  className={`text-sm font-semibold transition-colors ${currentView === 'HOME' ? 'text-brand-600' : 'text-slate-500 hover:text-slate-900'}`}
                >
                  Services
                </button>
                <button 
                  onClick={() => { setCurrentView('PORTFOLIO'); window.scrollTo({top: 0, behavior: 'smooth'}); }}
                  className={`text-sm font-semibold transition-colors ${currentView === 'PORTFOLIO' ? 'text-brand-600' : 'text-slate-500 hover:text-slate-900'}`}
                >
                  Portfolio
                </button>
            </div>

            <div className="flex items-center gap-2 md:gap-4">
              {deferredPrompt && (
                <button 
                  onClick={handleInstallClick}
                  className="bg-brand-600 text-white px-3 py-1.5 rounded-full text-xs font-bold hover:bg-brand-700 transition-colors flex items-center gap-1.5 shadow-lg animate-bounce"
                >
                  <Download className="w-3 h-3" /> Install App
                </button>
              )}
              <button 
                onClick={() => setCurrentView('ADMIN')}
                className="hidden md:flex text-xs font-bold text-slate-500 hover:text-brand-600 px-3 py-1.5 rounded-full hover:bg-slate-100 transition-colors items-center gap-1.5 uppercase tracking-wide"
              >
                <Shield className="w-3 h-3" /> Admin
              </button>
              <button className="bg-slate-900 text-white px-4 md:px-5 py-2 rounded-full text-sm font-medium hover:bg-slate-800 transition-colors shadow-lg shadow-slate-900/10">
                Contact
              </button>
            </div>
        </div>
      </header>

      <main className="relative z-10 pt-28 pb-16">
        
        {currentView === 'PORTFOLIO' && (
          <Portfolio />
        )}

        {currentView === 'HOME' && (
          <>
            {step === 1 && (
              <div className="animate-fade-in-up">
                {/* Hero Section */}
                <div className="max-w-6xl mx-auto px-4 mb-16 text-center relative">
                    {/* Optional Hero Background Graphic */}
                    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-full bg-gradient-to-b from-transparent via-white/40 to-transparent -z-10 blur-3xl rounded-full opacity-50"></div>

                    <span className="inline-block py-1.5 px-4 rounded-full bg-white/80 backdrop-blur-sm text-brand-600 text-xs font-bold uppercase tracking-wider mb-6 border border-brand-200 shadow-sm">
                        ✨ Premium Digital Services
                    </span>
                    <h1 className="text-5xl md:text-7xl font-extrabold text-slate-900 mb-6 font-heading tracking-tight leading-tight drop-shadow-sm">
                        Transforming Ideas into <br className="hidden md:block"/>
                        <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-600 via-purple-600 to-indigo-600">
                            Digital Reality
                        </span>
                    </h1>
                    <p className="text-lg md:text-xl text-slate-600 max-w-2xl mx-auto mb-10 leading-relaxed font-medium">
                        We craft high-converting websites and authoritative ebooks to help you establish your digital presence with impact.
                    </p>
                </div>

                <div className="max-w-4xl mx-auto px-4">
                    <AiConsultant onRecommendationAccepted={handleServiceSelect} />
                    
                    <div className="mt-16 mb-8 flex items-center justify-between">
                        <h2 className="text-2xl font-bold text-slate-900 font-heading">Our Services</h2>
                        <div className="h-px flex-1 bg-gradient-to-r from-slate-200 to-transparent ml-6"></div>
                    </div>

                    <ServiceSelection 
                    selectedServiceId={details.serviceId || null} 
                    onSelect={(id) => handleServiceSelect(id)} 
                    />
                </div>

                {/* Full Width Portfolio Section */}
                <div className="bg-white/50 border-y border-white/50 backdrop-blur-sm my-16 py-8">
                   <Portfolio />
                </div>

                <div className="max-w-6xl mx-auto px-4">
                    <Reviews />
                </div>
              </div>
            )}

            {step > 1 && (
              <div className="max-w-4xl mx-auto px-4">
                {renderStepIndicator()}
              </div>
            )}

            {step === 2 && (
              <div className="max-w-5xl mx-auto px-4 animate-fade-in-up">
                <button 
                    onClick={() => setStep(1)} 
                    className="group flex items-center text-slate-500 hover:text-brand-600 mb-8 text-sm font-bold uppercase tracking-wide transition-colors"
                >
                    <div className="w-8 h-8 rounded-full bg-white border border-slate-200 flex items-center justify-center mr-3 group-hover:border-brand-200 group-hover:bg-brand-50 transition-colors shadow-sm">
                        <ArrowLeft className="w-4 h-4" /> 
                    </div>
                    Back to Services
                </button>
                
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    <div className="lg:col-span-2 space-y-8">
                        <div className="bg-white/80 backdrop-blur-md rounded-3xl p-8 border border-white/60 shadow-xl ring-1 ring-white/50">
                            <h2 className="text-2xl font-bold text-slate-900 mb-6 font-heading">Select a Session</h2>
                            <BookingCalendar 
                            onSlotSelect={handleSlotSelect} 
                            selectedSlot={details.slot} 
                            />
                        </div>
                    </div>
                    
                    {/* Summary Sidebar */}
                    <div className="lg:col-span-1">
                        <div className="glass-panel rounded-3xl p-6 shadow-xl sticky top-28 ring-1 ring-white/60">
                            <div className="flex items-center gap-2 mb-6 text-brand-600">
                                <Sparkles className="w-5 h-5" />
                                <h3 className="text-xs font-bold uppercase tracking-widest">Booking Summary</h3>
                            </div>
                            
                            <div className="mb-6">
                                <img 
                                    src={selectedService?.imageUrl} 
                                    alt={selectedService?.title} 
                                    className="w-full h-32 object-cover rounded-xl mb-4 shadow-md ring-1 ring-black/5"
                                />
                                <p className="font-bold text-xl text-slate-900 font-heading leading-tight mb-1">{selectedService?.title}</p>
                                <p className="text-brand-600 font-bold">{selectedService?.priceRange}</p>
                            </div>

                            <div className={`
                                mb-6 p-4 rounded-xl border transition-all duration-300
                                ${details.slot 
                                    ? 'bg-indigo-50/80 border-indigo-100' 
                                    : 'bg-slate-50/80 border-dashed border-slate-200'}
                            `}>
                                {details.slot ? (
                                    <>
                                        <p className="text-xs text-indigo-500 font-bold uppercase mb-1">Date & Time</p>
                                        <div className="flex items-baseline gap-2">
                                            <p className="text-lg font-bold text-indigo-900">
                                                {details.slot.date.toLocaleDateString(undefined, { month: 'short', day: 'numeric'})}
                                            </p>
                                            <p className="text-indigo-700 font-medium">
                                                @ {details.slot.time}
                                            </p>
                                        </div>
                                    </>
                                ) : (
                                    <p className="text-sm text-slate-400 text-center py-2">Select a date to continue</p>
                                )}
                            </div>

                            <Button 
                                className="w-full h-12 text-base shadow-lg shadow-brand-500/20 bg-gradient-to-r from-brand-600 to-indigo-600 hover:from-brand-700 hover:to-indigo-700" 
                                disabled={!details.slot} 
                                onClick={() => { setStep(3); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                            >
                                Continue to Details
                            </Button>
                        </div>
                    </div>
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="max-w-2xl mx-auto px-4 animate-fade-in-up">
                <button 
                    onClick={() => setStep(2)} 
                    className="group flex items-center text-slate-500 hover:text-brand-600 mb-8 text-sm font-bold uppercase tracking-wide transition-colors"
                >
                    <div className="w-8 h-8 rounded-full bg-white border border-slate-200 flex items-center justify-center mr-3 group-hover:border-brand-200 group-hover:bg-brand-50 transition-colors shadow-sm">
                        <ArrowLeft className="w-4 h-4" /> 
                    </div>
                    Back to Calendar
                </button>

                <div className="glass-panel rounded-3xl p-8 md:p-10 shadow-2xl ring-1 ring-white/60">
                    <div className="mb-8 border-b border-slate-100 pb-8">
                        <h2 className="text-3xl font-bold text-slate-900 mb-2 font-heading">Finalize Booking</h2>
                        <p className="text-slate-500">Please provide your details so we can prepare for our meeting.</p>
                    </div>
                    
                    <BookingForm details={details} onChange={handleDetailsChange} />
                    
                    <div className="mt-8 pt-8 border-t border-slate-100">
                        <div className="bg-slate-50/80 rounded-xl p-5 mb-8 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border border-slate-100">
                            <div className="flex items-center gap-4">
                                <div className="w-12 h-12 rounded-lg bg-cover bg-center shadow-sm" style={{backgroundImage: `url(${selectedService?.imageUrl})`}} />
                                <div>
                                    <p className="font-bold text-slate-900 text-sm">{selectedService?.title}</p>
                                    <p className="text-slate-500 text-xs mt-0.5">{details.slot?.date.toLocaleDateString()} at {details.slot?.time}</p>
                                </div>
                            </div>
                            <button onClick={() => setStep(1)} className="text-brand-600 hover:text-brand-700 text-xs font-bold uppercase tracking-wide underline decoration-2 underline-offset-4">Change</button>
                        </div>

                        <Button 
                            className="w-full text-lg h-14 rounded-xl shadow-xl shadow-brand-500/20 hover:shadow-brand-500/30 transition-all transform active:scale-[0.98] bg-gradient-to-r from-brand-600 to-indigo-600" 
                            disabled={!details.name || !details.email || !details.projectDescription} 
                            onClick={handleSubmit}
                            isLoading={isLoading}
                        >
                            Confirm Booking
                        </Button>
                    </div>
                </div>
              </div>
            )}

            {step === 4 && (
              <div className="max-w-lg mx-auto text-center px-4 pt-8 animate-fade-in-up">
                <div className="w-24 h-24 bg-gradient-to-br from-green-400 to-emerald-600 text-white rounded-full flex items-center justify-center mx-auto mb-8 shadow-2xl shadow-green-500/30 ring-4 ring-white">
                    <Check className="w-12 h-12" />
                </div>
                <h2 className="text-4xl font-extrabold text-slate-900 mb-4 font-heading">You're All Set!</h2>
                <p className="text-slate-600 mb-10 text-lg leading-relaxed">
                    Thank you, <strong className="text-slate-900">{details.name}</strong>. We've locked in your session for <strong>{selectedService?.title}</strong>. 
                    A confirmation has been sent to your email.
                </p>
                
                <div className="bg-white/90 backdrop-blur-md p-8 rounded-3xl border border-white shadow-xl mb-10 text-left relative overflow-hidden">
                    <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-brand-500 to-accent-500" />
                    <h3 className="font-bold text-slate-900 mb-6 font-heading flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-accent-500" /> Next Steps
                    </h3>
                    <ul className="space-y-6">
                        {[
                            "Check your email for the calendar invite.",
                            "Prepare any documents or assets mentioned in the service description.",
                            `We'll meet at the scheduled time: ${details.slot?.date.toLocaleDateString()} ${details.slot?.time}.`
                        ].map((text, i) => (
                            <li key={i} className="flex gap-4">
                                <div className="w-6 h-6 rounded-full bg-slate-100 flex items-center justify-center text-xs font-bold text-slate-500 shrink-0 border border-slate-200">{i+1}</div>
                                <p className="text-slate-600 text-sm">{text}</p>
                            </li>
                        ))}
                    </ul>
                </div>
                
                <Button variant="outline" className="px-8 py-3 rounded-xl border-slate-300 hover:border-slate-900 hover:bg-slate-50 shadow-sm" onClick={() => window.location.reload()}>
                    Book Another Service
                </Button>
              </div>
            )}
          </>
        )}

      </main>

      <footer className="relative z-10 bg-slate-900 text-white pt-20 pb-10 border-t border-slate-800 mt-auto">
        <div className="max-w-6xl mx-auto px-4 grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
            <div className="col-span-1 md:col-span-2">
                <div className="flex items-center gap-3 mb-6">
                    <div className="w-10 h-10 bg-gradient-to-br from-brand-500 to-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-brand-900/20">
                        <span className="text-white font-extrabold text-xl font-heading">v</span>
                    </div>
                    <span className="text-2xl font-bold font-heading">vix.Studio</span>
                </div>
                <p className="text-slate-400 text-sm leading-relaxed max-w-sm mb-8">
                    We are a premium digital agency dedicated to elevating your brand through world-class web development, strategic e-commerce solutions, and authoritative content creation.
                </p>
                <div className="flex gap-4">
                   <a 
                     href="https://www.linkedin.com/in/vickyexpert?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android app" 
                     target="_blank" 
                     rel="noreferrer"
                     className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-brand-600 transition-colors cursor-pointer text-slate-400 hover:text-white"
                     aria-label="LinkedIn"
                   >
                       <Linkedin className="w-4 h-4" />
                   </a>
                   <a 
                     href="https://www.instagram.com/vix_digital_studio?igsh=NmhtZXhlZ2gzYzBv" 
                     target="_blank" 
                     rel="noreferrer"
                     className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-brand-600 transition-colors cursor-pointer text-slate-400 hover:text-white"
                     aria-label="Instagram"
                   >
                       <Instagram className="w-4 h-4" />
                   </a>
                   <div className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-brand-600 transition-colors cursor-pointer text-slate-400 hover:text-white" aria-label="Twitter">
                       <Twitter className="w-4 h-4" />
                   </div>
                </div>
            </div>

            <div>
                <h4 className="font-bold text-lg mb-6 font-heading">Services</h4>
                <ul className="space-y-4 text-slate-400 text-sm">
                    <li className="hover:text-brand-400 cursor-pointer transition-colors">Web Development</li>
                    <li className="hover:text-brand-400 cursor-pointer transition-colors">Shopify Stores</li>
                    <li className="hover:text-brand-400 cursor-pointer transition-colors">Social Commerce</li>
                    <li className="hover:text-brand-400 cursor-pointer transition-colors">Ebook Writing</li>
                </ul>
            </div>

            <div>
                <h4 className="font-bold text-lg mb-6 font-heading">Work with Me</h4>
                <p className="text-slate-400 text-sm mb-6">Ready to start your project? Book directly or hire me on Fiverr.</p>
                <a 
                    href="https://www.fiverr.com/vickyxpert" 
                    target="_blank" 
                    rel="noreferrer"
                    className="inline-flex items-center justify-center px-6 py-3 rounded-xl bg-[#1DBF73] hover:bg-[#19a463] text-white font-bold transition-all shadow-lg hover:shadow-[#1DBF73]/20 w-full md:w-auto"
                >
                    Hire on Fiverr
                </a>
            </div>
        </div>

        <div className="max-w-6xl mx-auto px-4 pt-8 border-t border-slate-800 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-slate-500">
            <p>&copy; {new Date().getFullYear()} vix Digital Studio. All rights reserved.</p>
            <div className="flex gap-6">
                <span className="hover:text-slate-300 cursor-pointer">Privacy Policy</span>
                <span className="hover:text-slate-300 cursor-pointer">Terms of Service</span>
            </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
